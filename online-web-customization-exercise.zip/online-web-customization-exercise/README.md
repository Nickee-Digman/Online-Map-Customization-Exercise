# Online Web Customization Exercise

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nickee-Digman/pen/eYXwVJz](https://codepen.io/Nickee-Digman/pen/eYXwVJz).

